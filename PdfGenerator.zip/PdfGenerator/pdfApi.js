const express = require('express');
const app = express();
const logger = require('./utils/logger');
const pdfGenerator = require ('./pdfGenerator'); 
const bodyParser = require('body-parser');
// const customerData = require('./jsons/customerInfo');
// const jsonData = require('./jsons/data');
//const jsonData = require('./jsons/dataComparison');//for comparison template
// const jsonData = require('./jsons/dataFolloedTests');//for followed tests template
var uniqid = require('uniqid');


const port = 4000 ;

logger.info("application started");
app.use(bodyParser.json({limit:'1mb'}));//creates a new limit for request 
app.post('/pdf/', async (req,res)=>{
    logger.info(`api call started on memberId: ${req.body.header.member_id}`);
    const templateName = req.body.templateName;
    const headerData = req.body.header;
    const bodyData = req.body.body;

    const pdfName = `${headerData.member_id}_${templateName}_${uniqid()}`;
    
    pdfGenerator.generateJson(pdfName,templateName,bodyData,headerData).then((x)=>{
        console.log('generation success');
        logger.info(`api call ended`);
        res.send({base64:x});
    },(err)=>{
        console.log('generation failed');
        logger.error(`Member ID : ${headerData.member_id} , Template : ${templateName}  --- ${err}`);
        
        
        res.status(500).send();
        

    });
    
})

app.listen(port, () => console.log(`app listening on port ${port}!`))