var path = require('path');

const base = path.dirname(__filename).replace(/\\/g,"/").replace('config','');

console.log(base);
module.exports = {
    "basePath":`file:///${base}`,
    "createLocalPdf":true,
    "pdfAbsolutePath":'D:/Data/LogFiles/PdfGeneretor/'
}
